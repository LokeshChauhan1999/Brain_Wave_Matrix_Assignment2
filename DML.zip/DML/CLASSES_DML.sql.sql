REM INSERTING into CLASSES
SET DEFINE OFF;
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (1,'Mathematics 101',1);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (2,'Science 101',2);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (3,'English Literature',3);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (4,'History 101',4);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (5,'Geography 101',5);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (6,'Physics 101',6);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (7,'Chemistry 101',7);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (8,'Biology 101',8);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (9,'Computer Science',9);
Insert into CLASSES (CLASS_ID,CLASS_NAME,TEACHER_ID) values (10,'Physical Education',10);
