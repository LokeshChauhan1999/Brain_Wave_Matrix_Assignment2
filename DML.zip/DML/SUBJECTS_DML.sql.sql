REM INSERTING into SUBJECTS
SET DEFINE OFF;
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (1,'Mathematics');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (2,'Science');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (3,'English');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (4,'History');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (5,'Geography');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (6,'Computer Science');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (7,'Physical Education');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (8,'Art');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (9,'Music');
Insert into SUBJECTS (SUBJECT_ID,SUBJECT_NAME) values (10,'Chemistry');
