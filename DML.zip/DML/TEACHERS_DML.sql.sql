REM INSERTING into TEACHERS
SET DEFINE OFF;
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (1,'Raj','Kumar',1,'9876543210','raj.kumar@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (2,'Anita','Sharma',2,'9887654321','anita.sharma@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (3,'Suresh','Verma',3,'9765432109','suresh.verma@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (4,'Neeta','Singh',4,'9754321098','neeta.singh@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (5,'Vikram','Mehta',5,'9743210987','vikram.mehta@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (6,'Priya','Rao',6,'9732109876','priya.rao@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (7,'Ravi','Desai',7,'9721098765','ravi.desai@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (8,'Geeta','Patel',8,'9710987654','geeta.patel@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (9,'Rahul','Chopra',9,'9709876543','rahul.chopra@school.com');
Insert into TEACHERS (TEACHER_ID,FIRST_NAME,LAST_NAME,SUBJECT_ID,PHONE_NUMBER,EMAIL) values (10,'Kiran','Nair',10,'9698765432','kiran.nair@school.com');
